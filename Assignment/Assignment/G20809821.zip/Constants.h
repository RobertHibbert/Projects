#pragma once
const unsigned int ARRAY_SIZE = 100; //this is the size of the stack, this can be set to any number but i have selected this for testing.
const unsigned int STACK_TOP = 99;// this is the value of the top of the stack.
const unsigned int STACK_BOTTOM = -1;// this is the first value of bottom of the stack (off the stack)